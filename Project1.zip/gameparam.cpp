#include "gameparam.h"
#include <iostream>
#include <fstream>  
#include <sstream>  
#include <string>  
using namespace std;

Cgameparam::Cgameparam(){
	;
};
Cgameparam::Cgameparam(int s, int l, equipment e) {
	score = s;
	level = l;
	equip = e;

};
Cgameparam::~Cgameparam() {
	;
}
int Cgameparam::getscore() {
	return score;
}
int Cgameparam::getlevel() {
	return level;
}
equipment Cgameparam::getequip() {
    return equip;
}
void Cgameparam::oputtxt(const string& filename) {
	ofstream file(filename);
	if (!file.is_open()) {
		cout << "Error opening file: " << filename << endl;
		return;
	}
	else {
		file << "Gameparam" << endl;
		file << "Gamescore:" << score <<endl;
		file << "Gamelevel:" << level << endl;
		file << "Gameequip:" << equip << endl;
	}
	file.close();
}
void Cgameparam::iputtxt(const string& filename) {
	ifstream file(filename);
	if (!file.is_open()) {
		cout << "Error opening file: " << filename << endl;
		return;
	}
	else{
		string line;
		getline(file, line);
		file.close();
	}

	}
}
