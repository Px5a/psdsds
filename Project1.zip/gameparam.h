#pragma once
#include <iostream>  
#include <fstream>  
#include <sstream>  
#include <string>  
#ifndef __GAMEPARAM_H__
#define __GAMEPARAM_H__

enum equipment {
	sword = 0,
	wand,
	spear,
	shield
};
class Cgameparam {
    int score;
    int level;
	equipment equip;
public:
	Cgameparam();
	Cgameparam(int,int,equipment);
	~Cgameparam();
	int getscore();
	int getlevel();
	equipment getequip();
	void oputtxt(const string& filename);
	void iputtxt(const string& filename);



};







#endif
