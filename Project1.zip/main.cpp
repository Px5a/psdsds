#include <iostream>
#include <fstream>  
#include <sstream>  
#include <string>  
using namespace std;

int main() {











}